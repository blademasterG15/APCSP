# We add here
def plus(x,y):
    return x+y
    # We subtract here
def subtract(x,y):
    return x-y
    # We multiply here
def multiply(x,y):
    return x*y
    # We divide here
def divide(x,y):
    return x/y

result = None
while True:
    
    # Take what type of operation does the user wants
    user_choice = input("Do you want to add/subtract/multiply/divide? ")
    print(user_choice)
    
    # Take the numbers that the user wants
    num1 = float(input("Enter the first number: "))
    print(num1)
    num2 = float(input("Enter the second number: "))
    print(num2)
    
    list_of_functions = [plus, subtract, multiply, divide]   
    # Calculate what the user wants and print it
    user_choice = user_choice.lower()
    if user_choice == "add":
        result = list_of_functions[0](num1,num2)
    elif user_choice == "subtract":
        result = list_of_functions[1](num1,num2)
    elif user_choice == "multiply":
        result = list_of_functions[2](num1,num2)
    elif user_choice == "divide":
        if num2 == 0:
            print("Divisor Cannot be Zero")
        else:
            result = list_of_functions[3](num1,num2)
    else:
        print("sorry error!")
    if result is not None:
        print("The result is: " + str(result))
    
    user_wants = input("Do you wish to continue using the calculator, type yes/no: ")
    user_choice = user_choice.lower()
    
    if user_wants == "yes":
        continue
    else:
        break